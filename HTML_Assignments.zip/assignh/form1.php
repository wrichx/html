<?php include "templates/header.php"; ?><h2>User Details</h2>

<section>
<form method="post">
	<label for="PhoneNumber">Contact Person Phone Number*
		<input type="text" name="PhoneNumber" id="PhoneNumber" placeholder="Contact Person Phone Number" required> <br>
	</label>
	<label for="Site Name/ Estate">Site Name/ Estate*
		<input type="text" name="SiteName" id="SiteName" placeholder="Site Name/ Estate"> <br>
	</label>
	<label for="HouseNumber">House Number
		<input type="text" name="HouseNumber" id="HouseNumber" placeholder="House Number"><br>
	</label>
	<label for="DateReported">Date Reported
		<input type="date" name="DateReported" id="DateReported"><br>
	</label>
		<label for="ScheduledTime">Scheduled Time
		YES: <input type="radio" name="yes" value="1"> 
		NO: <input type="radio" name="no" value="0"> <br>
    <input type="time" name="Scheduled_Time" id="Scheduled_Time"><br>
	</label>
		<label for="assigned">Assigned To
		<input type="text" name="assignedto" id="assignedto" placeholder="Assigned Engineer"><br>
	</label>
	<div>
		<label for="attachement">Attachment (optional)</label>
		<input type="file" name="attachement" id="attachement" placeholder="Upload Flie Here. Can Be Doc or IMG"><br>
	</div>
	<input type="submit" name="save" value="Save">
</form>
</section>

<?php include "templates/footer.php"; ?>