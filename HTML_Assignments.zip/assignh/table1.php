<?php include "templates/header.php"; ?><h2>Table</h2>

<table>
	<tr>
		<th rowspan="2"></th>
		<th colspan="2">Average</th>
		<th rowspan="2">Red Eyes</th>
		
	</tr>

    <tr>
    	<th>Height</th>
    	<th>Weight</th>
    </tr>

    <tr>
    	<td>Males</td>
    	<td>1.9</td>
    	<td>0.003</td>
    	<td>40%</td>
    </tr>

    <tr>
    	<td>Females</td>
    	<td>1.7</td>
    	<td>0.002</td>
    	<td>43%</td>
    </tr>

    <tr>
    	<td>Others</td>
    	<td>12</td>
    	<td>34</td>
    	<td>45%</td>
    </tr>

</table>

<?php include "templates/footer.php"; ?>