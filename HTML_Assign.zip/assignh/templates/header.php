<!doctype html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Simple Registration Form</title>

	<link rel="stylesheet" href="assets/css/main.css">
</head>

<body>
    <h1>Simple Registration Form</h1>
    <nav>
        <a href="form1.php"><strong>FORM</strong></a> - - || - -
        <a href="canvas.php"><strong>CANVAS</strong></a> - - || - -
		<a href="table1.php"><strong>TABLE</strong></a> - - ||
    </nav>