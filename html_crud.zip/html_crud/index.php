<?php include "templates/header.php"; ?>



<section>
	<h2>Home Is Where The Heard Is</h2>
	<h4>Where is yours?</h4>
	<p>
		Be that as it ma, ideally is where I welcome you to my page. However, I dont have much to say so just use the navigation and find your way. kapish?... kapish!
	</p>
</section>
<article>
	<a href="www.utl.co.ke"> <img src="image/Madaraka.jpg" alt="Madaraka day special"> </a>
	<marquee> Come Celebrate Madaraka Day With Us! We have something for everyone </marquee>
</article>

<aside>
	<ol type="i" start="3" >
		<li>My name</li>
		<li>My House</li>
		<li>My Life</li>
	</ol>
</aside>

<?php include "templates/footer.php"; ?>