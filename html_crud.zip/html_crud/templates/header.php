<!doctype html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>wrx - crud</title>

	<link rel="stylesheet" href="css/style.css">
</head>

<body>
	<h1>wrx - crud</h1>

	<nav>
		<a href="index.php"><strong>HOME</strong></a> - - || - -
		<a href="create.php"><strong>CREATE</strong></a> - - || - -
		<a href="read.php"><strong>READ</strong></a> - - || - -
		<a href="update.php"><strong>UPDATE</strong></a> - - ||
		<a href="delete.php"><strong>DELETE</strong></a> - - ||
	</nav>

<hr>