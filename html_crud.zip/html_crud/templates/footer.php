<hr>

<nav>
		<a href="index.php">Home</a> - || -
		<a href="create.php">Create</a> - || -
		<a href="read.php">Read</a> - || -
		<a href="update.php">Update</a> - || -
		<a href="delete.php">Delete</a> - ||
	</nav>
<p>Any thoughts comments, contributions? <a href="mailto:richw.ogola@gmail.com"> Inboxx ASAP!</a> </p>
<footer>Powered by wrichx* © 2018</footer>
</body>
</html>